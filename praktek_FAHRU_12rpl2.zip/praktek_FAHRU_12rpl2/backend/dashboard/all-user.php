<?php include "templates/header.php"; include 'fungsi/functionM.php';?>
<?php 
  $user = queryM("SELECT * FROM user"); $i=1;
?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-gray-800">User</h1>
  <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i> Tambah</a>
</div>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-info">Daftar user</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive mt-3">
                <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Username</th>
                      <th>Level</th>
                      <th>Email</th>
                      <th>poto</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($user as $data): ?>
                      <tr>
                        <td><?= $i++; ?></td>
                        <td><?= $data['username'] ?></td>
                        <td><?= $data['level'] ?></td>
                        <td><?= $data['email'] ?></td>
                        <td>
                          <img src="img/<?= $data['poto'] ?>" class="img img-responsive" style="width: 100px;" alt="">
                        </td>
                      </tr>
                    <?php endforeach ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

<?php include "templates/footer.php"; ?>