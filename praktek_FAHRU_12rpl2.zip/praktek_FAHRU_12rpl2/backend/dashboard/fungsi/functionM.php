<?php 
$conn = mysqli_connect('localhost', 'fahru','fahruropiyu290801','siechocaffe');

function queryM( $query ) {
	global $conn;
	
	$res = mysqli_query($conn, $query);
	$rows = [];
	while ( $row = mysqli_fetch_assoc($res) ) {
		$rows[] = $row;
	}

	return $rows;
}

function simpanM($data) {
	global $conn;

	$kdM = $data['kdM'];
	$nami = $data['namiM'];
	$hargi = $data['hargiM'];
	$stok = $data['stokM'];
	$kategori = $data['ktM'];
	$gambar = "img/default.jpg";

	return mysqli_query($conn, "INSERT INTO menu VALUES  ('$kdM', '$nami', '$hargi', '$stok', '$gambar', '$kategori', '1') ");

}

function hapusM($idM) {
	global $conn;

	return mysqli_query($conn, "DELETE FROM menu WHERE kd_menu = '$idM' ");
}

function ubahM($data) {
	global $conn;

	$kdM = $data['kdM'];
	$nami = $data['namiM'];
	$hargi = $data['hargiM'];
	$stok = $data['stokM'];
	$kategori = $data['ktM'];

	return mysqli_query($conn, "UPDATE menu SET nama_menu = '$nami', harga = '$hargi', stok = '$stok', poto = 'nopic.jfif', kd_kategori = '$kategori', id_hal = '1' WHERE kd_menu = '$kdM' ");
}

function ubahUser( $data ) {
	global $conn;

	$username = $_POST['username'];
	$gambarLama = htmlspecialchars($data["gambarLama"]);

	// cek apakah user pilih gambar baru atau tidak
	if ( $_FILES['gambar']['error'] === 4 ) {
		$gambar = $gambarLama;
	} else {
		$gambar = uploadPoto();
	}

	return mysqli_query($conn, "UPDATE user SET poto = '$gambar' WHERE username = '$username'");
}

function uploadPoto() {
	$namaFile = $_FILES['gambar']['name'];
	$ukuranFile = $_FILES['gambar']['size'];
	$error = $_FILES['gambar']['error'];
	$tmpName = $_FILES['gambar']['tmp_name'];

	//cek apakah tidak ada gambar yang di upload
	if ( $error === 4 ) {
		echo "<script>alert('Gambar belum dipilih')</script>";
		return false;
	}

	//cek file yang di upload
	$ekstensiGambarValid = ["jpg", "jpeg", "png"];
	$ekstensiGambar = explode('.', $namaFile);
	$ekstensiGambar = strtolower(end($ekstensiGambar));
	if ( !in_array($ekstensiGambar, $ekstensiGambarValid)) {
		echo "<script>alert('Bukan Gambar')</script>";
		return false;
	}

	// cek ukuran gambar
	if ( $ukuranFile > 1000000 ) {
		echo "<script>alert('Ukuran Gambar Terlalu besar')</script>";
		return false;
	}

	// lolos pengecekan, gambar siap diupload
	// generate nama gambar baru
	$namaFileBaru = uniqid();
	$namaFileBaru .= '.';
	$namaFileBaru .= $ekstensiGambar;

	move_uploaded_file($tmpName, '../img/' . $namaFileBaru);

	return $namaFileBaru;

}