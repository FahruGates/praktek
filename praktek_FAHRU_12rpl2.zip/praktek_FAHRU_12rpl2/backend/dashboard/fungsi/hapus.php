<?php 
include 'functionM.php';
	
	$kdM = $_GET['kdM'];

	if ( hapusM($kdM) > 0) {
		header('location: ../menu.php?pesan=menuHok');
	} else {
		header('location: ../menu.php?pesan=menuHerr');
	}