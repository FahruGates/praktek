<?php 

mysqli_connect('localhost', 'fahru','fahruropiyu290801','siechocaffe') ? print_r('ok') : die('koneksi bermasalah');