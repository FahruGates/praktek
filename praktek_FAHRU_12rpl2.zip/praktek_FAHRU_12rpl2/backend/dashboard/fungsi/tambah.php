<?php 
include 'functionM.php';

if ( isset($_POST['sub'])) {
	
	if ( simpanM($_POST) > 0 ) {
		header('location: ../menu.php?pesan=menuOk');
	} else {
		header('location: ../menu.php?pesan=menuErr');
	}

}

 ?>