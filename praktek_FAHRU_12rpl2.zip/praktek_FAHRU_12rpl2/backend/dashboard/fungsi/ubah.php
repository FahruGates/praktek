<?php 
include 'functionM.php';

if ( isset($_POST['sub'])) {
	if ( ubahM($_POST) > 0) {
		header('location: ../menu.php?pesan=menuUok');
	} else {
		header('location: ../menu.php?pesan=menuUerr');
	}

} else if (isset($_POST['ubahU'])) {
	if ( ubahUser($_POST) > 0) {
		header('location: ../user.php?pesan=Uok');
	} else {
		header('location: ../user.php?pesan=Uerr');
	}
}