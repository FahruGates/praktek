<?php
include 'templates/header.php';

if ( $_SESSION['level'] == "admin") {
	include 'terasAdmin.php';
} elseif ( $_SESSION['level'] = "kasir") {
	include 'terasKasir.php';
}

include 'templates/footer.php';