$(function() {

	$('.tombolTambahData').on('click', function() {
		$('#JudulModal').html('Tambah pesanan');	
		$('.modal-footer button[type=submit]').html('Tambah Data');
	});

	$('.tampilModalUbah').on('click', function() {

		$('#JudulModal').html('Ubah pesanan');
		$('.modal-footer button[type=submit]').html('Ubah Data');
		$('.modal-body form').attr('action', 'http://localhost/praktek/backend/dashboard/tambahpesanan.php');

		const id = $(this).data('id');

		$.ajax({
			url: 'http://localhost/praktek/backend/dashboard/tambahpesanan.php',
			data: {id: id},
			method: 'post',
			dataType: 'json',
			success: function(data) {
				$('#nama').val(data.nama);
				$('#email').val(data.email);
				$('#password').val(data.password);
				$('#jenis').val(data.jenis);
				$('#id').val(data.id);
			}
		});

	});

});