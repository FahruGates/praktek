<?php include "templates/header.php"; include 'fungsi/functionM.php';?>
<?php 
  $menu = queryM("SELECT * FROM meja");
?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-gray-800">Meja</h1>
  <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i> Tambah</a>
</div>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-info">Daftar menu</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive mt-3">
                <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>nomor meja</th>
                      <th>Status</th>
                      <th>Opsi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($menu as $data): ?>
                      <tr>
                        <td><?= $data['no_meja'] ?></td>
                        <td><?= $data['status'] ?></td>
                        <td>
                          <a class="btn btn-sm btn-warning" href=""><span class="fa fa-pen"></span> Ubah</a>
                          <a class="btn btn-sm btn-danger" href="" onclick="return confirm('yakin?');"><span class="fa fa-trash"></span> Hapus</a>
                        </td>
                      </tr>
                    <?php endforeach ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

<?php include "templates/footer.php"; ?>