<?php include "templates/header.php"; include
 'fungsi/functionM.php';?>
<?php 
  $menu = queryM("SELECT * FROM menu"); $i=1;
?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-gray-800">Menu</h1>
  <button type="button" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" data-toggle="modal" data-target="#formModal">
    <i class="fas fa-fw fa-plus"></i> Tambah
  </button>
</div>
<div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-info">Daftar menu</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive mt-3">
        <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>No</th>
              <th>Kategori</th>
              <th>Nama</th>
              <th>Harga</th>
              <th>Stok</th>
              <th>Opsi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($menu as $data): ?>
              <?php $kdKat = $data['kd_kategori']; ?>
              <?php $kategori = queryM("SELECT * FROM kategori WHERE kd_kategori = '$kdKat' ");?>
              <tr>
                <td><?= $i++; ?></td>
              <?php foreach ($kategori as $k): ?>
                <td><?= $k['nama_kategori']; ?></td>
              <?php endforeach ?>
                <td><?= $data['nama_menu'] ?></td>
                <td><?= $data['harga'] ?></td>
                <td><?= $data['stok'] ?></td>
                <td>
                  <a class="btn btn-sm btn-warning" href="editMenu.php?kdM=<?= $data['kd_menu'] ?>"><span class="fa fa-pen"></span> Ubah</a>
                  <a class="btn btn-sm btn-danger" href="fungsi/hapus.php?kdM=<?= $data['kd_menu'] ?>" onclick="return confirm('yakin?');"><span class="fa fa-trash"></span> Hapus</a>
                </td>
              </tr>
            <?php endforeach ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

<?php include "templates/footer.php"; ?>