<?php include 'templates/header.php'; include 'fungsi/functionM.php'; ?>
<?php $kategori = queryM("SELECT * FROM kategori"); ?>
<?php $menu = queryM("SELECT * FROM menu ORDER BY kd_menu desc limit 1"); ?>

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-gray-800">Tambah rencang sangu</h1>
  <a href="menu.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"> Kembali</a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-info">Tambah rencang sangu</h6>
    </div>
    <div class="card-body">
    	
	<form action="fungsi/tambah.php" method="post" enctype="multypart/form-data">
		<div class="row">
			<div class="col-md-4">
					<?php foreach ($menu as $m): ?>
					<?php $kd = $m['kd_menu'];$kd = substr($kd, 2) + 1;$kd = "m_$kd";?>
						<input type="hidden" name="kdM" class="form-control" value="<?= $kd ?>" readonly="">
					<?php endforeach ?>
				<div class="form-group">
					<label for="">Nami</label>
					<input type="text" name="namiM" class="form-control">
				</div>
				<div class="form-group">
					<label for="">Hargi</label>
					<input type="text" name="hargiM" class="form-control">
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<label for="">Stok</label>
					<input type="text" name="stokM" class="form-control">
				</div>
				<div class="form-group">
					<label for="">Kategori</label>
					<select name="ktM" class="form-control">
						<?php foreach ($kategori as $data): ?>
							<option value="<?= $data['kd_kategori'] ?>"><?= $data['nama_kategori'] ?></option>
						<?php endforeach ?>
					</select>
				</div>
				<div class="form-group mt-4">
					<label for="">Pilih poto</label>
					<input type="file" name="gambar">
				</div>

			</div>
			<div class="col-md-4 mt-4">
				<center>
					<img src="img/undraw_posting_photo.svg" class="img-responsive" width="100%">
				</center>
			</div>
		</div>
		<button type="submit" name="sub" class="btn btn-primary btn-block mt-4">Simpan</button>
	</form>

    </div>
</div>

<?php include 'templates/footer.php'; ?>