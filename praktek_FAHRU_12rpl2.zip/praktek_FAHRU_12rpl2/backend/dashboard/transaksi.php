<?php include "templates/header.php"; include 'fungsi/functionM.php';?>
<?php 
$a = false;
if (isset($_POST['nomeja'])) 
{

  $nomeja = $_POST['nomeja'];
  $pesanan = queryM("SELECT * FROM pesanan WHERE no_meja = '$nomeja'");

 foreach ($pesanan as $pes):
    $idP = $pes['id_pelanggan']; $kdM = $pes['kd_menu'];
    $menu = queryM("SELECT * FROM menu where kd_menu = '$kdM' ");
 foreach ($menu as $m):
   $total = $m['harga'] * $pes['jumlah'];
  endforeach;
  endforeach;

$a = !false;

}

 ?>

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-gray-800">Transaksi Pesanan</h1>
</div>

<div class="row">
  <!-- inputan -->
  <div class="col-md-2">
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Transaksi</h6>
      </div>
      <div class="card-body">
        <form action="" method="post">
          <div class="form-group">
            <input type="text" name="nomeja" class="form-control" placeholder="nomor meja">
          </div>
          
          <div class="form-group">
            <button type="submit" class="btn btn-block btn-outline-secondary">Cek</button>
          </div>

        </form>
      </div>
    </div>
  </div>
  
  <?php if ($a == true): ?>
  <!-- inputan -->
  <div class="col-md-4">
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
          Transaksi (RP) 
          <button class="btn btn-sm btn-primary float-right">Print faktur</button>
        </h6>
      </div>
      <div class="card-body">
        <form action="">
          <div class="form-group">
            <label for="">Total Bayar</label>
            <input type="number" name="total" class="form-control" disabled="" value="<?= $total ?>">
          </div>

          <div class="form-group">
            <label for="">Bayar</label>
            <input type="number" class="form-control" name="bayar">
          </div>

          <div class="form-group">
            <label for="">Kembalian</label>
            <input type="number" name="nomeja" class="form-control">
          </div>

        </form>
      </div>
    </div>
  </div>
  <?php endif ?>

  <?php if ($a == true): ?>
    <!-- pesanan -->
    <div class="col-md-6">
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Daftar pesanan</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive mt-3">
        <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Nama Menu</th>
              <th>Pelanggan</th>
              <th>QTY</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($pesanan as $pes): ?>
            <?php $idP = $pes['id_pelanggan']; $kdM = $pes['kd_menu'];
              $menu = queryM("SELECT * FROM menu where kd_menu = '$kdM' ");
              $pelanggan = queryM("SELECT * FROM pelanggan where id_pelanggan = '$idP' "); 
            ?>
            <?php foreach ($menu as $m): ?>
            <?php foreach ($pelanggan as $pel): ?>
             <tr>
                <td><?= $m['nama_menu'] ?></td>
                <td><?= $pel['nama_pelanggan'] ?></td>
                <td><?= $pes['jumlah'] ?></td>
                <td><?= $m['harga'] * $pes['jumlah'] ?></td>
            </tr>
            <?php endforeach ?>
            <?php endforeach ?>
            <?php endforeach ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
    </div>
  <?php endif ?>


</div>

<?php include "templates/footer.php"; ?>