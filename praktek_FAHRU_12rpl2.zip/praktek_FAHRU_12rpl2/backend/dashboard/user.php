<?php include 'templates/header.php'; include 'fungsi/functionM.php'; ?>
<?php $nama = $_SESSION['username']; ?>
<?php $user = queryM("SELECT * FROM user WHERE username = '$nama'") ?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-gray-800">Pengaturan akun</h1>
</div>

<div class="row">
	<div class="col-md-4">
		<div class="card shadow mb-4">
			<div class="card-header py-3">
				<h6 class="m-0 font-weight-bold text-info">Pengaturan akun</h6>
			</div>
			<div class="card-body">
				<form action="" class="form-group">
					<div class="form-group">
						<label for="">Username / email</label>
						<input type="text" class="form-control">
					</div>
					<div class="form-group">
						<label for="">Password</label>
						<input type="password" class="form-control">
					</div>
					<div class="form-group">
						<label for="">Confirm password</label>
						<input type="password" class="form-control">
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary btn-md form-control">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<?php foreach ( $user as $u ) : ?>
	<div class="col-md-4">
		<div class="card shadow mb-4">
			<div class="card-header py-3">
				<h6 class="m-0 font-weight-bold text-info">Pengaturan poto</h6>
			</div>
			<div class="card-body">
				<form action="fungsi/ubah.php" method="post" class="form-group" enctype="multipart/form-data">
					<img src="img/<?= $u['poto'] ?>" width="100%" class="img-responsive" alt="">
					<div class="form-group mt-4">
						<label for="">Pilih poto</label>
						<input type="file" name="gambar">
					</div>
					<div class="form-group">
						<input type="hidden" name="gambarLama" value="<?= $u['poto']; ?>">
						<input type="hidden" name="username" value="<?= $nama; ?>" >
						<button type="submit" name="ubahU" class="btn btn-primary btn-md form-control">Perbarui</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php endforeach ?>

<?php include 'templates/footer.php'; ?>