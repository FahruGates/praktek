<?php 

$conn = mysqli_connect("localhost","fahru","fahruropiyu290801","siechocaffe");