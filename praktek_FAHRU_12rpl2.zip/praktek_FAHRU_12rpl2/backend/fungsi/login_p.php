<?php 

session_start();
require 'koneksi.php';

$username = mysqli_escape_string($conn, $_POST['username']);
$password = mysqli_escape_string($conn ,$_POST['password']);

$res = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username' AND password = '$password' ");
$cek = mysqli_num_rows($res);

if ( $cek > 0) {
	
	$data = mysqli_fetch_array($res);

	if ( $data['level'] == "admin") {
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "admin";
		$_SESSION['gambar'] = $data['poto'];
		header('location: ../dashboard/index.php');
	} elseif ( $data['level'] == "kasir") {
		$_SESSION['username'] = $username;
		$_SESSION['level'] = "kasir";
		$_SESSION['gambar'] = $data['poto'];
		header('location: ../dashboard/index.php');
	} else {
		header('../login.php?pesan=gagal');
	}

} else {
	header('location: ../login.php?pesan=gagal');
}
