<!DOCTYPE html>
<?php include 'fungsi/f.php'; ?>
<?php 
  $no = 1;
  $kategori = query("SELECT * FROM kategori");

  // pagination
 // konfigurasi
 $jumlahDataPerHalaman = 6;
 $jumlahData = count(query("SELECT * FROM menu"));

if (isset($_POST['selkat'])) {
   $kat = $_POST['selkat'];
   $jumlahData = count(query("SELECT * FROM menu WHERE kd_kategori = '$kat'"));
}

 $jumlahHalaman = ceil($jumlahData / $jumlahDataPerHalaman);
 $halamanAktif = ( isset($_GET["halaman"]) ) ? $_GET["halaman"] : 1;
 $awalData = ( $jumlahDataPerHalaman * $halamanAktif ) - $jumlahDataPerHalaman;

 $menu = query("SELECT * FROM menu LIMIT $awalData, $jumlahDataPerHalaman");

 ?>

<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Menu</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">


  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

</head>

<body>

  <!--/ Intro Single star /-->
  <section class="intro-single">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-8">
          <div class="title-single-box">
            <h1 class="title-single">
              Menu kape
            </h1>
            <div class="grid-option">
            <form method="post" action="">
              <div class="form-group">
               <div class="input-group mb-3">
                <select class="custom-select" name="selkat" aria-describedby="basic-addon2">
                  <option selected>All</option>
                  <?php foreach ($kategori as $k): ?>
                    <option value="<?= $k['kd_kategori'] ?>"><?= $k['nama_kategori'] ?></option>
                  <?php endforeach ?>
                </select>
                <div class="input-group-append">
                  <button class="btn btn-primary" type="submit">
                    Ok
                  </button>
                </div>
               </div>
              </div>
            </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--/ Intro Single End /-->

  <!--/ Property Grid Star /-->
  <section class="property-grid grid">
    <div class="container">
      <div class="row">
<?php foreach ($menu as $m): ?>
        <div class="col-md-4">
          <div class="card-box-b card-shadow news-box">
            <div class="img-box-b">
              <img src="img/nopic.jfif" alt="" class="img-b img-fluid">
            </div>
            <div class="card-overlay">
              <div class="card-header-b">
                <div class="card-category-b">
                  <a href="#" class="category-b">
                    <?php if ($m['stok'] > 0): ?>
                      Tersedia
                    <?php else : ?>
                      Kosong
                    <?php endif ?>
                  </a>
                </div>
                <div class="card-title-b">
                  <h2 class="title-2" style="color: white;">
                    <?= $m['nama_menu'] ?>
                  </h2>
                </div>
                <div class="card-date">
                  <span class="date-b">Rp.<?= $m['harga'] ?></span>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php endforeach ?>
      </div>
      <!-- paggin awal-->
      <div class="row">
        <div class="col-sm-12">
          <nav class="pagination-a">
            <ul class="pagination justify-content-end">
              <li class="page-item">
              <?php if ( $halamanAktif > 1 ): ?>
                <a class="page-link" href="?halaman=<?= $halamanAktif - 1 ?>">
                  <span class="ion-ios-arrow-back"></span>
                </a>
              <?php endif; ?>
              </li>
              <?php for ($j=1; $j <= $jumlahHalaman ; $j++) : ?>

                <?php if ( $j == $halamanAktif): ?>
                  <li class="page-item active">
                    <a href="?halaman=<?= $j ?>" class="page-link" ><?= $j ?></a>
                  </li>
                <?php else: ?>
                  <li class="page-item">
                    <a href="?halaman=<?= $j ?>" class="page-link"><?= $j ?></a>
                  </li>
                <?php endif; ?>

              <?php endfor; ?>
              <li class="page-item next">
              <?php if ($halamanAktif < $jumlahHalaman ): ?>
                <a class="page-link" href="?halaman=<?= $halamanAktif + 1 ?>">
                  <span class="ion-ios-arrow-forward"></span>
                </a>
              <?php endif ?>
              </li>
            </ul>
          </nav>
        </div>
      </div>
      <!-- paging ahir-->
    </div>
  </section>
  <!--/ Property Grid End /-->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <div id="preloader"></div>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/popper/popper.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/scrollreveal/scrollreveal.min.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>
</html>
